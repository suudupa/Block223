/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.0.4181.a593105a9 modeling language!*/

package ca.mcgill.ecse223.block.model;
import java.util.*;

// line 101 "../../../../../Model.ump"
public class PlayArea extends DisplayArea
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //PlayArea Associations
  private PlayPhase playPhase;
  private List<PhysicalBlock> blocks;
  private Ball ball;
  private List<Wall> walls;
  private Paddle paddle;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public PlayArea(int aWidth, int aHeight, PlayPhase aPlayPhase, Paddle aPaddle)
  {
    super(aWidth, aHeight);
    if (aPlayPhase == null || aPlayPhase.getPlayArea() != null)
    {
      throw new RuntimeException("Unable to create PlayArea due to aPlayPhase");
    }
    playPhase = aPlayPhase;
    blocks = new ArrayList<PhysicalBlock>();
    walls = new ArrayList<Wall>();
    if (aPaddle == null || aPaddle.getPlayArea() != null)
    {
      throw new RuntimeException("Unable to create PlayArea due to aPaddle");
    }
    paddle = aPaddle;
  }

  public PlayArea(int aWidth, int aHeight, Game aGameForPlayPhase, int aScoreForPlayPhase, Player aPlayerForPlayPhase, int aXForPaddle, int aYForPaddle)
  {
    super(aWidth, aHeight);
    playPhase = new PlayPhase(aGameForPlayPhase, aScoreForPlayPhase, this, aPlayerForPlayPhase);
    blocks = new ArrayList<PhysicalBlock>();
    walls = new ArrayList<Wall>();
    paddle = new Paddle(aXForPaddle, aYForPaddle, this);
  }

  //------------------------
  // INTERFACE
  //------------------------
  /* Code from template association_GetOne */
  public PlayPhase getPlayPhase()
  {
    return playPhase;
  }
  /* Code from template association_GetMany */
  public PhysicalBlock getBlock(int index)
  {
    PhysicalBlock aBlock = blocks.get(index);
    return aBlock;
  }

  public List<PhysicalBlock> getBlocks()
  {
    List<PhysicalBlock> newBlocks = Collections.unmodifiableList(blocks);
    return newBlocks;
  }

  public int numberOfBlocks()
  {
    int number = blocks.size();
    return number;
  }

  public boolean hasBlocks()
  {
    boolean has = blocks.size() > 0;
    return has;
  }

  public int indexOfBlock(PhysicalBlock aBlock)
  {
    int index = blocks.indexOf(aBlock);
    return index;
  }
  /* Code from template association_GetOne */
  public Ball getBall()
  {
    return ball;
  }

  public boolean hasBall()
  {
    boolean has = ball != null;
    return has;
  }
  /* Code from template association_GetMany */
  public Wall getWall(int index)
  {
    Wall aWall = walls.get(index);
    return aWall;
  }

  public List<Wall> getWalls()
  {
    List<Wall> newWalls = Collections.unmodifiableList(walls);
    return newWalls;
  }

  public int numberOfWalls()
  {
    int number = walls.size();
    return number;
  }

  public boolean hasWalls()
  {
    boolean has = walls.size() > 0;
    return has;
  }

  public int indexOfWall(Wall aWall)
  {
    int index = walls.indexOf(aWall);
    return index;
  }
  /* Code from template association_GetOne */
  public Paddle getPaddle()
  {
    return paddle;
  }
  /* Code from template association_MinimumNumberOfMethod */
  public static int minimumNumberOfBlocks()
  {
    return 0;
  }
  /* Code from template association_AddManyToOne */
  public PhysicalBlock addBlock(int aX, int aY, int aRow, int aColumn, boolean aBroken, BlockTemplate aTemplate)
  {
    return new PhysicalBlock(aX, aY, aRow, aColumn, aBroken, aTemplate, this);
  }

  public boolean addBlock(PhysicalBlock aBlock)
  {
    boolean wasAdded = false;
    if (blocks.contains(aBlock)) { return false; }
    PlayArea existingPlayArea = aBlock.getPlayArea();
    boolean isNewPlayArea = existingPlayArea != null && !this.equals(existingPlayArea);
    if (isNewPlayArea)
    {
      aBlock.setPlayArea(this);
    }
    else
    {
      blocks.add(aBlock);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeBlock(PhysicalBlock aBlock)
  {
    boolean wasRemoved = false;
    //Unable to remove aBlock, as it must always have a playArea
    if (!this.equals(aBlock.getPlayArea()))
    {
      blocks.remove(aBlock);
      wasRemoved = true;
    }
    return wasRemoved;
  }
  /* Code from template association_AddIndexControlFunctions */
  public boolean addBlockAt(PhysicalBlock aBlock, int index)
  {  
    boolean wasAdded = false;
    if(addBlock(aBlock))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfBlocks()) { index = numberOfBlocks() - 1; }
      blocks.remove(aBlock);
      blocks.add(index, aBlock);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveBlockAt(PhysicalBlock aBlock, int index)
  {
    boolean wasAdded = false;
    if(blocks.contains(aBlock))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfBlocks()) { index = numberOfBlocks() - 1; }
      blocks.remove(aBlock);
      blocks.add(index, aBlock);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addBlockAt(aBlock, index);
    }
    return wasAdded;
  }
  /* Code from template association_SetOptionalOneToOne */
  public boolean setBall(Ball aNewBall)
  {
    boolean wasSet = false;
    if (ball != null && !ball.equals(aNewBall) && equals(ball.getPlay()))
    {
      //Unable to setBall, as existing ball would become an orphan
      return wasSet;
    }

    ball = aNewBall;
    PlayArea anOldPlay = aNewBall != null ? aNewBall.getPlay() : null;

    if (!this.equals(anOldPlay))
    {
      if (anOldPlay != null)
      {
        anOldPlay.ball = null;
      }
      if (ball != null)
      {
        ball.setPlay(this);
      }
    }
    wasSet = true;
    return wasSet;
  }
  /* Code from template association_IsNumberOfValidMethod */
  public boolean isNumberOfWallsValid()
  {
    boolean isValid = numberOfWalls() >= minimumNumberOfWalls() && numberOfWalls() <= maximumNumberOfWalls();
    return isValid;
  }
  /* Code from template association_RequiredNumberOfMethod */
  public static int requiredNumberOfWalls()
  {
    return 4;
  }
  /* Code from template association_MinimumNumberOfMethod */
  public static int minimumNumberOfWalls()
  {
    return 4;
  }
  /* Code from template association_MaximumNumberOfMethod */
  public static int maximumNumberOfWalls()
  {
    return 4;
  }
  /* Code from template association_AddMNToOnlyOne */
  public Wall addWall(int aX, int aY)
  {
    if (numberOfWalls() >= maximumNumberOfWalls())
    {
      return null;
    }
    else
    {
      return new Wall(aX, aY, this);
    }
  }

  public boolean addWall(Wall aWall)
  {
    boolean wasAdded = false;
    if (walls.contains(aWall)) { return false; }
    if (numberOfWalls() >= maximumNumberOfWalls())
    {
      return wasAdded;
    }

    PlayArea existingPlayArea = aWall.getPlayArea();
    boolean isNewPlayArea = existingPlayArea != null && !this.equals(existingPlayArea);

    if (isNewPlayArea && existingPlayArea.numberOfWalls() <= minimumNumberOfWalls())
    {
      return wasAdded;
    }

    if (isNewPlayArea)
    {
      aWall.setPlayArea(this);
    }
    else
    {
      walls.add(aWall);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeWall(Wall aWall)
  {
    boolean wasRemoved = false;
    //Unable to remove aWall, as it must always have a playArea
    if (this.equals(aWall.getPlayArea()))
    {
      return wasRemoved;
    }

    //playArea already at minimum (4)
    if (numberOfWalls() <= minimumNumberOfWalls())
    {
      return wasRemoved;
    }
    walls.remove(aWall);
    wasRemoved = true;
    return wasRemoved;
  }

  public void delete()
  {
    PlayPhase existingPlayPhase = playPhase;
    playPhase = null;
    if (existingPlayPhase != null)
    {
      existingPlayPhase.delete();
    }
    while (blocks.size() > 0)
    {
      PhysicalBlock aBlock = blocks.get(blocks.size() - 1);
      aBlock.delete();
      blocks.remove(aBlock);
    }
    
    Ball existingBall = ball;
    ball = null;
    if (existingBall != null)
    {
      existingBall.delete();
      existingBall.setPlay(null);
    }
    while (walls.size() > 0)
    {
      Wall aWall = walls.get(walls.size() - 1);
      aWall.delete();
      walls.remove(aWall);
    }
    
    Paddle existingPaddle = paddle;
    paddle = null;
    if (existingPaddle != null)
    {
      existingPaddle.delete();
    }
    super.delete();
  }

}