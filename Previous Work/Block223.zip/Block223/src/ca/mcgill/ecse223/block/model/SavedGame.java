/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.0.4181.a593105a9 modeling language!*/

package ca.mcgill.ecse223.block.model;

// line 110 "../../../../../Model.ump"
public class SavedGame
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //SavedGame Associations
  private Player player;
  private PlayPhase pausedPlayPhase;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public SavedGame(Player aPlayer, PlayPhase aPausedPlayPhase)
  {
    boolean didAddPlayer = setPlayer(aPlayer);
    if (!didAddPlayer)
    {
      throw new RuntimeException("Unable to create savedGame due to player");
    }
    boolean didAddPausedPlayPhase = setPausedPlayPhase(aPausedPlayPhase);
    if (!didAddPausedPlayPhase)
    {
      throw new RuntimeException("Unable to create save due to pausedPlayPhase");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------
  /* Code from template association_GetOne */
  public Player getPlayer()
  {
    return player;
  }
  /* Code from template association_GetOne */
  public PlayPhase getPausedPlayPhase()
  {
    return pausedPlayPhase;
  }
  /* Code from template association_SetOneToOptionalOne */
  public boolean setPlayer(Player aNewPlayer)
  {
    boolean wasSet = false;
    if (aNewPlayer == null)
    {
      //Unable to setPlayer to null, as savedGame must always be associated to a player
      return wasSet;
    }
    
    SavedGame existingSavedGame = aNewPlayer.getSavedGame();
    if (existingSavedGame != null && !equals(existingSavedGame))
    {
      //Unable to setPlayer, the current player already has a savedGame, which would be orphaned if it were re-assigned
      return wasSet;
    }
    
    Player anOldPlayer = player;
    player = aNewPlayer;
    player.setSavedGame(this);

    if (anOldPlayer != null)
    {
      anOldPlayer.setSavedGame(null);
    }
    wasSet = true;
    return wasSet;
  }
  /* Code from template association_SetOneToOptionalOne */
  public boolean setPausedPlayPhase(PlayPhase aNewPausedPlayPhase)
  {
    boolean wasSet = false;
    if (aNewPausedPlayPhase == null)
    {
      //Unable to setPausedPlayPhase to null, as save must always be associated to a pausedPlayPhase
      return wasSet;
    }
    
    SavedGame existingSave = aNewPausedPlayPhase.getSave();
    if (existingSave != null && !equals(existingSave))
    {
      //Unable to setPausedPlayPhase, the current pausedPlayPhase already has a save, which would be orphaned if it were re-assigned
      return wasSet;
    }
    
    PlayPhase anOldPausedPlayPhase = pausedPlayPhase;
    pausedPlayPhase = aNewPausedPlayPhase;
    pausedPlayPhase.setSave(this);

    if (anOldPausedPlayPhase != null)
    {
      anOldPausedPlayPhase.setSave(null);
    }
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    Player existingPlayer = player;
    player = null;
    if (existingPlayer != null)
    {
      existingPlayer.setSavedGame(null);
    }
    PlayPhase existingPausedPlayPhase = pausedPlayPhase;
    pausedPlayPhase = null;
    if (existingPausedPlayPhase != null)
    {
      existingPausedPlayPhase.setSave(null);
    }
  }

}