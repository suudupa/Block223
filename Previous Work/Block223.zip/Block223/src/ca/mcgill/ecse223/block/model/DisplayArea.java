/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.0.4181.a593105a9 modeling language!*/

package ca.mcgill.ecse223.block.model;

/**
 * Represents a section of the screen
 */
// line 92 "../../../../../Model.ump"
public class DisplayArea
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //DisplayArea Attributes
  private int width;
  private int height;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public DisplayArea(int aWidth, int aHeight)
  {
    width = aWidth;
    height = aHeight;
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setWidth(int aWidth)
  {
    boolean wasSet = false;
    width = aWidth;
    wasSet = true;
    return wasSet;
  }

  public boolean setHeight(int aHeight)
  {
    boolean wasSet = false;
    height = aHeight;
    wasSet = true;
    return wasSet;
  }

  public int getWidth()
  {
    return width;
  }

  public int getHeight()
  {
    return height;
  }

  public void delete()
  {}


  public String toString()
  {
    return super.toString() + "["+
            "width" + ":" + getWidth()+ "," +
            "height" + ":" + getHeight()+ "]";
  }
}