/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.0.4181.a593105a9 modeling language!*/

package ca.mcgill.ecse223.block.model;

// line 39 "../../../../../Model.ump"
public class LevelDesign
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //LevelDesign Associations
  private Game game;
  private BlockArangement blockArangement;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public LevelDesign(Game aGame)
  {
    boolean didAddGame = setGame(aGame);
    if (!didAddGame)
    {
      throw new RuntimeException("Unable to create level due to game");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------
  /* Code from template association_GetOne */
  public Game getGame()
  {
    return game;
  }
  /* Code from template association_GetOne */
  public BlockArangement getBlockArangement()
  {
    return blockArangement;
  }

  public boolean hasBlockArangement()
  {
    boolean has = blockArangement != null;
    return has;
  }
  /* Code from template association_SetOneToMany */
  public boolean setGame(Game aGame)
  {
    boolean wasSet = false;
    if (aGame == null)
    {
      return wasSet;
    }

    Game existingGame = game;
    game = aGame;
    if (existingGame != null && !existingGame.equals(aGame))
    {
      existingGame.removeLevel(this);
    }
    game.addLevel(this);
    wasSet = true;
    return wasSet;
  }
  /* Code from template association_SetOptionalOneToOne */
  public boolean setBlockArangement(BlockArangement aNewBlockArangement)
  {
    boolean wasSet = false;
    if (blockArangement != null && !blockArangement.equals(aNewBlockArangement) && equals(blockArangement.getLevel()))
    {
      //Unable to setBlockArangement, as existing blockArangement would become an orphan
      return wasSet;
    }

    blockArangement = aNewBlockArangement;
    LevelDesign anOldLevel = aNewBlockArangement != null ? aNewBlockArangement.getLevel() : null;

    if (!this.equals(anOldLevel))
    {
      if (anOldLevel != null)
      {
        anOldLevel.blockArangement = null;
      }
      if (blockArangement != null)
      {
        blockArangement.setLevel(this);
      }
    }
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    Game placeholderGame = game;
    this.game = null;
    if(placeholderGame != null)
    {
      placeholderGame.removeLevel(this);
    }
    BlockArangement existingBlockArangement = blockArangement;
    blockArangement = null;
    if (existingBlockArangement != null)
    {
      existingBlockArangement.delete();
    }
  }

}