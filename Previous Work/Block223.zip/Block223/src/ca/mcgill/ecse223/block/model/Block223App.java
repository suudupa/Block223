/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.0.4181.a593105a9 modeling language!*/

package ca.mcgill.ecse223.block.model;
import java.util.*;

/**
 * The Main app
 */
// line 157 "../../../../../Model.ump"
public class Block223App
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Block223App Associations
  private List<User> users;
  private GamePhase gamePhase;
  private DisplayArea displayArea;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Block223App(DisplayArea aDisplayArea)
  {
    users = new ArrayList<User>();
    if (!setDisplayArea(aDisplayArea))
    {
      throw new RuntimeException("Unable to create Block223App due to aDisplayArea");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------
  /* Code from template association_GetMany */
  public User getUser(int index)
  {
    User aUser = users.get(index);
    return aUser;
  }

  public List<User> getUsers()
  {
    List<User> newUsers = Collections.unmodifiableList(users);
    return newUsers;
  }

  public int numberOfUsers()
  {
    int number = users.size();
    return number;
  }

  public boolean hasUsers()
  {
    boolean has = users.size() > 0;
    return has;
  }

  public int indexOfUser(User aUser)
  {
    int index = users.indexOf(aUser);
    return index;
  }
  /* Code from template association_GetOne */
  public GamePhase getGamePhase()
  {
    return gamePhase;
  }

  public boolean hasGamePhase()
  {
    boolean has = gamePhase != null;
    return has;
  }
  /* Code from template association_GetOne */
  public DisplayArea getDisplayArea()
  {
    return displayArea;
  }
  /* Code from template association_MinimumNumberOfMethod */
  public static int minimumNumberOfUsers()
  {
    return 0;
  }
  /* Code from template association_AddUnidirectionalMany */
  public boolean addUser(User aUser)
  {
    boolean wasAdded = false;
    if (users.contains(aUser)) { return false; }
    users.add(aUser);
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeUser(User aUser)
  {
    boolean wasRemoved = false;
    if (users.contains(aUser))
    {
      users.remove(aUser);
      wasRemoved = true;
    }
    return wasRemoved;
  }
  /* Code from template association_AddIndexControlFunctions */
  public boolean addUserAt(User aUser, int index)
  {  
    boolean wasAdded = false;
    if(addUser(aUser))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfUsers()) { index = numberOfUsers() - 1; }
      users.remove(aUser);
      users.add(index, aUser);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveUserAt(User aUser, int index)
  {
    boolean wasAdded = false;
    if(users.contains(aUser))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfUsers()) { index = numberOfUsers() - 1; }
      users.remove(aUser);
      users.add(index, aUser);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addUserAt(aUser, index);
    }
    return wasAdded;
  }
  /* Code from template association_SetUnidirectionalOptionalOne */
  public boolean setGamePhase(GamePhase aNewGamePhase)
  {
    boolean wasSet = false;
    gamePhase = aNewGamePhase;
    wasSet = true;
    return wasSet;
  }
  /* Code from template association_SetUnidirectionalOne */
  public boolean setDisplayArea(DisplayArea aNewDisplayArea)
  {
    boolean wasSet = false;
    if (aNewDisplayArea != null)
    {
      displayArea = aNewDisplayArea;
      wasSet = true;
    }
    return wasSet;
  }

  public void delete()
  {
    users.clear();
    gamePhase = null;
    displayArea = null;
  }

}