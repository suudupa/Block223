/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.0.4181.a593105a9 modeling language!*/

package ca.mcgill.ecse223.block.model;

// line 82 "../../../../../Model.ump"
public class Paddle extends PhysicalGameEntity
{

  //------------------------
  // STATIC VARIABLES
  //------------------------

  public static final int WIDTH = 5;

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Paddle Associations
  private PlayArea playArea;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Paddle(int aX, int aY, PlayArea aPlayArea)
  {
    super(aX, aY);
    if (aPlayArea == null || aPlayArea.getPaddle() != null)
    {
      throw new RuntimeException("Unable to create Paddle due to aPlayArea");
    }
    playArea = aPlayArea;
  }

  public Paddle(int aX, int aY, int aWidthForPlayArea, int aHeightForPlayArea, PlayPhase aPlayPhaseForPlayArea)
  {
    super(aX, aY);
    playArea = new PlayArea(aWidthForPlayArea, aHeightForPlayArea, aPlayPhaseForPlayArea, this);
  }

  //------------------------
  // INTERFACE
  //------------------------
  /* Code from template association_GetOne */
  public PlayArea getPlayArea()
  {
    return playArea;
  }

  public void delete()
  {
    PlayArea existingPlayArea = playArea;
    playArea = null;
    if (existingPlayArea != null)
    {
      existingPlayArea.delete();
    }
    super.delete();
  }


  public String toString()
  {
    return super.toString() + "["+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "playArea = "+(getPlayArea()!=null?Integer.toHexString(System.identityHashCode(getPlayArea())):"null");
  }
}