/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.0.4181.a593105a9 modeling language!*/

package ca.mcgill.ecse223.block.model;

// line 67 "../../../../../Model.ump"
public class PhysicalBlock extends PhysicalGameEntity
{

  //------------------------
  // STATIC VARIABLES
  //------------------------

  public static final int SIDE_LENGTH = 20;

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //PhysicalBlock Attributes
  private int row;
  private int column;
  private boolean broken;

  //PhysicalBlock Associations
  private BlockTemplate template;
  private PlayArea playArea;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public PhysicalBlock(int aX, int aY, int aRow, int aColumn, boolean aBroken, BlockTemplate aTemplate, PlayArea aPlayArea)
  {
    super(aX, aY);
    row = aRow;
    column = aColumn;
    broken = aBroken;
    boolean didAddTemplate = setTemplate(aTemplate);
    if (!didAddTemplate)
    {
      throw new RuntimeException("Unable to create instance due to template");
    }
    boolean didAddPlayArea = setPlayArea(aPlayArea);
    if (!didAddPlayArea)
    {
      throw new RuntimeException("Unable to create block due to playArea");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setRow(int aRow)
  {
    boolean wasSet = false;
    row = aRow;
    wasSet = true;
    return wasSet;
  }

  public boolean setColumn(int aColumn)
  {
    boolean wasSet = false;
    column = aColumn;
    wasSet = true;
    return wasSet;
  }

  public boolean setBroken(boolean aBroken)
  {
    boolean wasSet = false;
    broken = aBroken;
    wasSet = true;
    return wasSet;
  }

  public int getRow()
  {
    return row;
  }

  public int getColumn()
  {
    return column;
  }

  public boolean getBroken()
  {
    return broken;
  }
  /* Code from template attribute_IsBoolean */
  public boolean isBroken()
  {
    return broken;
  }
  /* Code from template association_GetOne */
  public BlockTemplate getTemplate()
  {
    return template;
  }
  /* Code from template association_GetOne */
  public PlayArea getPlayArea()
  {
    return playArea;
  }
  /* Code from template association_SetOneToMany */
  public boolean setTemplate(BlockTemplate aTemplate)
  {
    boolean wasSet = false;
    if (aTemplate == null)
    {
      return wasSet;
    }

    BlockTemplate existingTemplate = template;
    template = aTemplate;
    if (existingTemplate != null && !existingTemplate.equals(aTemplate))
    {
      existingTemplate.removeInstance(this);
    }
    template.addInstance(this);
    wasSet = true;
    return wasSet;
  }
  /* Code from template association_SetOneToMany */
  public boolean setPlayArea(PlayArea aPlayArea)
  {
    boolean wasSet = false;
    if (aPlayArea == null)
    {
      return wasSet;
    }

    PlayArea existingPlayArea = playArea;
    playArea = aPlayArea;
    if (existingPlayArea != null && !existingPlayArea.equals(aPlayArea))
    {
      existingPlayArea.removeBlock(this);
    }
    playArea.addBlock(this);
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    BlockTemplate placeholderTemplate = template;
    this.template = null;
    if(placeholderTemplate != null)
    {
      placeholderTemplate.removeInstance(this);
    }
    PlayArea placeholderPlayArea = playArea;
    this.playArea = null;
    if(placeholderPlayArea != null)
    {
      placeholderPlayArea.removeBlock(this);
    }
    super.delete();
  }


  public String toString()
  {
    return super.toString() + "["+
            "row" + ":" + getRow()+ "," +
            "column" + ":" + getColumn()+ "," +
            "broken" + ":" + getBroken()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "template = "+(getTemplate()!=null?Integer.toHexString(System.identityHashCode(getTemplate())):"null") + System.getProperties().getProperty("line.separator") +
            "  " + "playArea = "+(getPlayArea()!=null?Integer.toHexString(System.identityHashCode(getPlayArea())):"null");
  }
}