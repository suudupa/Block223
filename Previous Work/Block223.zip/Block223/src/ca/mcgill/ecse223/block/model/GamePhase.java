/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.0.4181.a593105a9 modeling language!*/

package ca.mcgill.ecse223.block.model;

// line 42 "../../../../../Model.ump"
public class GamePhase
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //GamePhase Associations
  private Game game;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public GamePhase(Game aGame)
  {
    boolean didAddGame = setGame(aGame);
    if (!didAddGame)
    {
      throw new RuntimeException("Unable to create gamePhase due to game");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------
  /* Code from template association_GetOne */
  public Game getGame()
  {
    return game;
  }
  /* Code from template association_SetOneToOptionalOne */
  public boolean setGame(Game aNewGame)
  {
    boolean wasSet = false;
    if (aNewGame == null)
    {
      //Unable to setGame to null, as gamePhase must always be associated to a game
      return wasSet;
    }
    
    GamePhase existingGamePhase = aNewGame.getGamePhase();
    if (existingGamePhase != null && !equals(existingGamePhase))
    {
      //Unable to setGame, the current game already has a gamePhase, which would be orphaned if it were re-assigned
      return wasSet;
    }
    
    Game anOldGame = game;
    game = aNewGame;
    game.setGamePhase(this);

    if (anOldGame != null)
    {
      anOldGame.setGamePhase(null);
    }
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    Game existingGame = game;
    game = null;
    if (existingGame != null)
    {
      existingGame.setGamePhase(null);
    }
  }

}