/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.0.4181.a593105a9 modeling language!*/

package ca.mcgill.ecse223.block.model;
import java.awt.Color;
import java.util.*;

// line 33 "../../../../../Model.ump"
public class BlockTemplate
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //BlockTemplate Attributes
  private int points;

  //BlockTemplate Associations
  private Color color;
  private Game game;
  private List<PhysicalBlock> instances;
  private BlockArangement arrangment;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public BlockTemplate(int aPoints, Color aColor, Game aGame, BlockArangement aArrangment)
  {
    points = aPoints;
    if (!setColor(aColor))
    {
      throw new RuntimeException("Unable to create BlockTemplate due to aColor");
    }
    boolean didAddGame = setGame(aGame);
    if (!didAddGame)
    {
      throw new RuntimeException("Unable to create block due to game");
    }
    instances = new ArrayList<PhysicalBlock>();
    boolean didAddArrangment = setArrangment(aArrangment);
    if (!didAddArrangment)
    {
      throw new RuntimeException("Unable to create template due to arrangment");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setPoints(int aPoints)
  {
    boolean wasSet = false;
    points = aPoints;
    wasSet = true;
    return wasSet;
  }

  public int getPoints()
  {
    return points;
  }
  /* Code from template association_GetOne */
  public Color getColor()
  {
    return color;
  }
  /* Code from template association_GetOne */
  public Game getGame()
  {
    return game;
  }
  /* Code from template association_GetMany */
  public PhysicalBlock getInstance(int index)
  {
    PhysicalBlock aInstance = instances.get(index);
    return aInstance;
  }

  public List<PhysicalBlock> getInstances()
  {
    List<PhysicalBlock> newInstances = Collections.unmodifiableList(instances);
    return newInstances;
  }

  public int numberOfInstances()
  {
    int number = instances.size();
    return number;
  }

  public boolean hasInstances()
  {
    boolean has = instances.size() > 0;
    return has;
  }

  public int indexOfInstance(PhysicalBlock aInstance)
  {
    int index = instances.indexOf(aInstance);
    return index;
  }
  /* Code from template association_GetOne */
  public BlockArangement getArrangment()
  {
    return arrangment;
  }
  /* Code from template association_SetUnidirectionalOne */
  public boolean setColor(Color aNewColor)
  {
    boolean wasSet = false;
    if (aNewColor != null)
    {
      color = aNewColor;
      wasSet = true;
    }
    return wasSet;
  }
  /* Code from template association_SetOneToMany */
  public boolean setGame(Game aGame)
  {
    boolean wasSet = false;
    if (aGame == null)
    {
      return wasSet;
    }

    Game existingGame = game;
    game = aGame;
    if (existingGame != null && !existingGame.equals(aGame))
    {
      existingGame.removeBlock(this);
    }
    game.addBlock(this);
    wasSet = true;
    return wasSet;
  }
  /* Code from template association_MinimumNumberOfMethod */
  public static int minimumNumberOfInstances()
  {
    return 0;
  }
  /* Code from template association_AddManyToOne */
  public PhysicalBlock addInstance(int aX, int aY, int aRow, int aColumn, boolean aBroken, PlayArea aPlayArea)
  {
    return new PhysicalBlock(aX, aY, aRow, aColumn, aBroken, this, aPlayArea);
  }

  public boolean addInstance(PhysicalBlock aInstance)
  {
    boolean wasAdded = false;
    if (instances.contains(aInstance)) { return false; }
    BlockTemplate existingTemplate = aInstance.getTemplate();
    boolean isNewTemplate = existingTemplate != null && !this.equals(existingTemplate);
    if (isNewTemplate)
    {
      aInstance.setTemplate(this);
    }
    else
    {
      instances.add(aInstance);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeInstance(PhysicalBlock aInstance)
  {
    boolean wasRemoved = false;
    //Unable to remove aInstance, as it must always have a template
    if (!this.equals(aInstance.getTemplate()))
    {
      instances.remove(aInstance);
      wasRemoved = true;
    }
    return wasRemoved;
  }
  /* Code from template association_AddIndexControlFunctions */
  public boolean addInstanceAt(PhysicalBlock aInstance, int index)
  {  
    boolean wasAdded = false;
    if(addInstance(aInstance))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfInstances()) { index = numberOfInstances() - 1; }
      instances.remove(aInstance);
      instances.add(index, aInstance);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveInstanceAt(PhysicalBlock aInstance, int index)
  {
    boolean wasAdded = false;
    if(instances.contains(aInstance))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfInstances()) { index = numberOfInstances() - 1; }
      instances.remove(aInstance);
      instances.add(index, aInstance);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addInstanceAt(aInstance, index);
    }
    return wasAdded;
  }
  /* Code from template association_SetOneToMany */
  public boolean setArrangment(BlockArangement aArrangment)
  {
    boolean wasSet = false;
    if (aArrangment == null)
    {
      return wasSet;
    }

    BlockArangement existingArrangment = arrangment;
    arrangment = aArrangment;
    if (existingArrangment != null && !existingArrangment.equals(aArrangment))
    {
      existingArrangment.removeTemplate(this);
    }
    arrangment.addTemplate(this);
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    color = null;
    Game placeholderGame = game;
    this.game = null;
    if(placeholderGame != null)
    {
      placeholderGame.removeBlock(this);
    }
    for(int i=instances.size(); i > 0; i--)
    {
      PhysicalBlock aInstance = instances.get(i - 1);
      aInstance.delete();
    }
    BlockArangement placeholderArrangment = arrangment;
    this.arrangment = null;
    if(placeholderArrangment != null)
    {
      placeholderArrangment.removeTemplate(this);
    }
  }


  public String toString()
  {
    return super.toString() + "["+
            "points" + ":" + getPoints()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "color = "+(getColor()!=null?Integer.toHexString(System.identityHashCode(getColor())):"null") + System.getProperties().getProperty("line.separator") +
            "  " + "game = "+(getGame()!=null?Integer.toHexString(System.identityHashCode(getGame())):"null") + System.getProperties().getProperty("line.separator") +
            "  " + "arrangment = "+(getArrangment()!=null?Integer.toHexString(System.identityHashCode(getArrangment())):"null");
  }
}