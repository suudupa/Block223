/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.0.4181.a593105a9 modeling language!*/

package ca.mcgill.ecse223.block.model;

// line 44 "../../../../../Model.ump"
public class PlayPhase extends GamePhase
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //PlayPhase Attributes
  private int score;
  private int numLives;

  //PlayPhase Associations
  private PlayArea playArea;
  private Player player;
  private SavedGame save;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public PlayPhase(Game aGame, int aScore, PlayArea aPlayArea, Player aPlayer)
  {
    super(aGame);
    score = aScore;
    numLives = 3;
    if (aPlayArea == null || aPlayArea.getPlayPhase() != null)
    {
      throw new RuntimeException("Unable to create PlayPhase due to aPlayArea");
    }
    playArea = aPlayArea;
    boolean didAddPlayer = setPlayer(aPlayer);
    if (!didAddPlayer)
    {
      throw new RuntimeException("Unable to create playPhase due to player");
    }
  }

  public PlayPhase(Game aGame, int aScore, int aWidthForPlayArea, int aHeightForPlayArea, Paddle aPaddleForPlayArea, Player aPlayer)
  {
    super(aGame);
    score = aScore;
    numLives = 3;
    playArea = new PlayArea(aWidthForPlayArea, aHeightForPlayArea, this, aPaddleForPlayArea);
    boolean didAddPlayer = setPlayer(aPlayer);
    if (!didAddPlayer)
    {
      throw new RuntimeException("Unable to create playPhase due to player");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setScore(int aScore)
  {
    boolean wasSet = false;
    score = aScore;
    wasSet = true;
    return wasSet;
  }

  public boolean setNumLives(int aNumLives)
  {
    boolean wasSet = false;
    numLives = aNumLives;
    wasSet = true;
    return wasSet;
  }

  public int getScore()
  {
    return score;
  }

  public int getNumLives()
  {
    return numLives;
  }
  /* Code from template association_GetOne */
  public PlayArea getPlayArea()
  {
    return playArea;
  }
  /* Code from template association_GetOne */
  public Player getPlayer()
  {
    return player;
  }
  /* Code from template association_GetOne */
  public SavedGame getSave()
  {
    return save;
  }

  public boolean hasSave()
  {
    boolean has = save != null;
    return has;
  }
  /* Code from template association_SetOneToOptionalOne */
  public boolean setPlayer(Player aNewPlayer)
  {
    boolean wasSet = false;
    if (aNewPlayer == null)
    {
      //Unable to setPlayer to null, as playPhase must always be associated to a player
      return wasSet;
    }
    
    PlayPhase existingPlayPhase = aNewPlayer.getPlayPhase();
    if (existingPlayPhase != null && !equals(existingPlayPhase))
    {
      //Unable to setPlayer, the current player already has a playPhase, which would be orphaned if it were re-assigned
      return wasSet;
    }
    
    Player anOldPlayer = player;
    player = aNewPlayer;
    player.setPlayPhase(this);

    if (anOldPlayer != null)
    {
      anOldPlayer.setPlayPhase(null);
    }
    wasSet = true;
    return wasSet;
  }
  /* Code from template association_SetOptionalOneToOne */
  public boolean setSave(SavedGame aNewSave)
  {
    boolean wasSet = false;
    if (save != null && !save.equals(aNewSave) && equals(save.getPausedPlayPhase()))
    {
      //Unable to setSave, as existing save would become an orphan
      return wasSet;
    }

    save = aNewSave;
    PlayPhase anOldPausedPlayPhase = aNewSave != null ? aNewSave.getPausedPlayPhase() : null;

    if (!this.equals(anOldPausedPlayPhase))
    {
      if (anOldPausedPlayPhase != null)
      {
        anOldPausedPlayPhase.save = null;
      }
      if (save != null)
      {
        save.setPausedPlayPhase(this);
      }
    }
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    PlayArea existingPlayArea = playArea;
    playArea = null;
    if (existingPlayArea != null)
    {
      existingPlayArea.delete();
    }
    Player existingPlayer = player;
    player = null;
    if (existingPlayer != null)
    {
      existingPlayer.setPlayPhase(null);
    }
    SavedGame existingSave = save;
    save = null;
    if (existingSave != null)
    {
      existingSave.delete();
    }
    super.delete();
  }


  public String toString()
  {
    return super.toString() + "["+
            "score" + ":" + getScore()+ "," +
            "numLives" + ":" + getNumLives()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "playArea = "+(getPlayArea()!=null?Integer.toHexString(System.identityHashCode(getPlayArea())):"null") + System.getProperties().getProperty("line.separator") +
            "  " + "player = "+(getPlayer()!=null?Integer.toHexString(System.identityHashCode(getPlayer())):"null") + System.getProperties().getProperty("line.separator") +
            "  " + "save = "+(getSave()!=null?Integer.toHexString(System.identityHashCode(getSave())):"null");
  }
}