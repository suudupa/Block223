/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.0.4181.a593105a9 modeling language!*/

package ca.mcgill.ecse223.block.model;

// line 50 "../../../../../Model.ump"
public class DesignPhase extends GamePhase
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //DesignPhase Associations
  private Admin user;
  private DesignArea designArea;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public DesignPhase(Game aGame, Admin aUser, DesignArea aDesignArea)
  {
    super(aGame);
    boolean didAddUser = setUser(aUser);
    if (!didAddUser)
    {
      throw new RuntimeException("Unable to create designPhase due to user");
    }
    if (aDesignArea == null || aDesignArea.getDesignPhase() != null)
    {
      throw new RuntimeException("Unable to create DesignPhase due to aDesignArea");
    }
    designArea = aDesignArea;
  }

  public DesignPhase(Game aGame, Admin aUser, int aWidthForDesignArea, int aHeightForDesignArea)
  {
    super(aGame);
    boolean didAddUser = setUser(aUser);
    if (!didAddUser)
    {
      throw new RuntimeException("Unable to create designPhase due to user");
    }
    designArea = new DesignArea(aWidthForDesignArea, aHeightForDesignArea, this);
  }

  //------------------------
  // INTERFACE
  //------------------------
  /* Code from template association_GetOne */
  public Admin getUser()
  {
    return user;
  }
  /* Code from template association_GetOne */
  public DesignArea getDesignArea()
  {
    return designArea;
  }
  /* Code from template association_SetOneToOptionalOne */
  public boolean setUser(Admin aNewUser)
  {
    boolean wasSet = false;
    if (aNewUser == null)
    {
      //Unable to setUser to null, as designPhase must always be associated to a user
      return wasSet;
    }
    
    DesignPhase existingDesignPhase = aNewUser.getDesignPhase();
    if (existingDesignPhase != null && !equals(existingDesignPhase))
    {
      //Unable to setUser, the current user already has a designPhase, which would be orphaned if it were re-assigned
      return wasSet;
    }
    
    Admin anOldUser = user;
    user = aNewUser;
    user.setDesignPhase(this);

    if (anOldUser != null)
    {
      anOldUser.setDesignPhase(null);
    }
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    Admin existingUser = user;
    user = null;
    if (existingUser != null)
    {
      existingUser.setDesignPhase(null);
    }
    DesignArea existingDesignArea = designArea;
    designArea = null;
    if (existingDesignArea != null)
    {
      existingDesignArea.delete();
    }
    super.delete();
  }

}