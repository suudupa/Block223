/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.0.4181.a593105a9 modeling language!*/

package ca.mcgill.ecse223.block.model;

// line 75 "../../../../../Model.ump"
public class Ball extends PhysicalGameEntity
{

  //------------------------
  // STATIC VARIABLES
  //------------------------

  public static final int DIAMETER = 10;

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Ball Attributes
  private int xVelocity;
  private int yVelocity;

  //Ball Associations
  private PlayArea play;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Ball(int aX, int aY, int aXVelocity, int aYVelocity, PlayArea aPlay)
  {
    super(aX, aY);
    xVelocity = aXVelocity;
    yVelocity = aYVelocity;
    boolean didAddPlay = setPlay(aPlay);
    if (!didAddPlay)
    {
      throw new RuntimeException("Unable to create ball due to play");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setXVelocity(int aXVelocity)
  {
    boolean wasSet = false;
    xVelocity = aXVelocity;
    wasSet = true;
    return wasSet;
  }

  public boolean setYVelocity(int aYVelocity)
  {
    boolean wasSet = false;
    yVelocity = aYVelocity;
    wasSet = true;
    return wasSet;
  }

  public int getXVelocity()
  {
    return xVelocity;
  }

  public int getYVelocity()
  {
    return yVelocity;
  }
  /* Code from template association_GetOne */
  public PlayArea getPlay()
  {
    return play;
  }
  /* Code from template association_SetOneToOptionalOne */
  public boolean setPlay(PlayArea aNewPlay)
  {
    boolean wasSet = false;
    if (aNewPlay == null)
    {
      //Unable to setPlay to null, as ball must always be associated to a play
      return wasSet;
    }
    
    Ball existingBall = aNewPlay.getBall();
    if (existingBall != null && !equals(existingBall))
    {
      //Unable to setPlay, the current play already has a ball, which would be orphaned if it were re-assigned
      return wasSet;
    }
    
    PlayArea anOldPlay = play;
    play = aNewPlay;
    play.setBall(this);

    if (anOldPlay != null)
    {
      anOldPlay.setBall(null);
    }
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    PlayArea existingPlay = play;
    play = null;
    if (existingPlay != null)
    {
      existingPlay.setBall(null);
    }
    super.delete();
  }


  public String toString()
  {
    return super.toString() + "["+
            "xVelocity" + ":" + getXVelocity()+ "," +
            "yVelocity" + ":" + getYVelocity()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "play = "+(getPlay()!=null?Integer.toHexString(System.identityHashCode(getPlay())):"null");
  }
}