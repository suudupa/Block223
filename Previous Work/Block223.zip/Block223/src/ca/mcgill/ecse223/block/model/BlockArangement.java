/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.0.4181.a593105a9 modeling language!*/

package ca.mcgill.ecse223.block.model;
import java.awt.Color;
import java.util.*;

// line 54 "../../../../../Model.ump"
public class BlockArangement
{

  //------------------------
  // STATIC VARIABLES
  //------------------------

  public static final int MAX_SIZE = 500;
  public static final int MIN_SIZE = 200;

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //BlockArangement Attributes
  private int numRows;
  private int numCols;

  //BlockArangement Associations
  private LevelDesign level;
  private List<BlockTemplate> templates;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public BlockArangement(int aNumRows, int aNumCols, LevelDesign aLevel)
  {
    numRows = aNumRows;
    numCols = aNumCols;
    boolean didAddLevel = setLevel(aLevel);
    if (!didAddLevel)
    {
      throw new RuntimeException("Unable to create blockArangement due to level");
    }
    templates = new ArrayList<BlockTemplate>();
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setNumRows(int aNumRows)
  {
    boolean wasSet = false;
    numRows = aNumRows;
    wasSet = true;
    return wasSet;
  }

  public boolean setNumCols(int aNumCols)
  {
    boolean wasSet = false;
    numCols = aNumCols;
    wasSet = true;
    return wasSet;
  }

  public int getNumRows()
  {
    return numRows;
  }

  public int getNumCols()
  {
    return numCols;
  }
  /* Code from template association_GetOne */
  public LevelDesign getLevel()
  {
    return level;
  }
  /* Code from template association_GetMany */
  public BlockTemplate getTemplate(int index)
  {
    BlockTemplate aTemplate = templates.get(index);
    return aTemplate;
  }

  public List<BlockTemplate> getTemplates()
  {
    List<BlockTemplate> newTemplates = Collections.unmodifiableList(templates);
    return newTemplates;
  }

  public int numberOfTemplates()
  {
    int number = templates.size();
    return number;
  }

  public boolean hasTemplates()
  {
    boolean has = templates.size() > 0;
    return has;
  }

  public int indexOfTemplate(BlockTemplate aTemplate)
  {
    int index = templates.indexOf(aTemplate);
    return index;
  }
  /* Code from template association_SetOneToOptionalOne */
  public boolean setLevel(LevelDesign aNewLevel)
  {
    boolean wasSet = false;
    if (aNewLevel == null)
    {
      //Unable to setLevel to null, as blockArangement must always be associated to a level
      return wasSet;
    }
    
    BlockArangement existingBlockArangement = aNewLevel.getBlockArangement();
    if (existingBlockArangement != null && !equals(existingBlockArangement))
    {
      //Unable to setLevel, the current level already has a blockArangement, which would be orphaned if it were re-assigned
      return wasSet;
    }
    
    LevelDesign anOldLevel = level;
    level = aNewLevel;
    level.setBlockArangement(this);

    if (anOldLevel != null)
    {
      anOldLevel.setBlockArangement(null);
    }
    wasSet = true;
    return wasSet;
  }
  /* Code from template association_MinimumNumberOfMethod */
  public static int minimumNumberOfTemplates()
  {
    return 0;
  }
  /* Code from template association_AddManyToOne */
  public BlockTemplate addTemplate(int aPoints, Color aColor, Game aGame)
  {
    return new BlockTemplate(aPoints, aColor, aGame, this);
  }

  public boolean addTemplate(BlockTemplate aTemplate)
  {
    boolean wasAdded = false;
    if (templates.contains(aTemplate)) { return false; }
    BlockArangement existingArrangment = aTemplate.getArrangment();
    boolean isNewArrangment = existingArrangment != null && !this.equals(existingArrangment);
    if (isNewArrangment)
    {
      aTemplate.setArrangment(this);
    }
    else
    {
      templates.add(aTemplate);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeTemplate(BlockTemplate aTemplate)
  {
    boolean wasRemoved = false;
    //Unable to remove aTemplate, as it must always have a arrangment
    if (!this.equals(aTemplate.getArrangment()))
    {
      templates.remove(aTemplate);
      wasRemoved = true;
    }
    return wasRemoved;
  }
  /* Code from template association_AddIndexControlFunctions */
  public boolean addTemplateAt(BlockTemplate aTemplate, int index)
  {  
    boolean wasAdded = false;
    if(addTemplate(aTemplate))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfTemplates()) { index = numberOfTemplates() - 1; }
      templates.remove(aTemplate);
      templates.add(index, aTemplate);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveTemplateAt(BlockTemplate aTemplate, int index)
  {
    boolean wasAdded = false;
    if(templates.contains(aTemplate))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfTemplates()) { index = numberOfTemplates() - 1; }
      templates.remove(aTemplate);
      templates.add(index, aTemplate);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addTemplateAt(aTemplate, index);
    }
    return wasAdded;
  }

  public void delete()
  {
    LevelDesign existingLevel = level;
    level = null;
    if (existingLevel != null)
    {
      existingLevel.setBlockArangement(null);
    }
    for(int i=templates.size(); i > 0; i--)
    {
      BlockTemplate aTemplate = templates.get(i - 1);
      aTemplate.delete();
    }
  }


  public String toString()
  {
    return super.toString() + "["+
            "numRows" + ":" + getNumRows()+ "," +
            "numCols" + ":" + getNumCols()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "level = "+(getLevel()!=null?Integer.toHexString(System.identityHashCode(getLevel())):"null");
  }
}