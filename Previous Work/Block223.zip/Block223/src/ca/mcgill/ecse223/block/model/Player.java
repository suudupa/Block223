/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.0.4181.a593105a9 modeling language!*/

package ca.mcgill.ecse223.block.model;
import java.util.*;
import java.sql.Date;

// line 17 "../../../../../Model.ump"
public class Player extends UserRole
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Player Associations
  private SavedGame savedGame;
  private List<Game> games;
  private List<HighScore> highScores;
  private PlayPhase playPhase;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Player(String aPassword, User aUser)
  {
    super(aPassword, aUser);
    games = new ArrayList<Game>();
    highScores = new ArrayList<HighScore>();
  }

  //------------------------
  // INTERFACE
  //------------------------
  /* Code from template association_GetOne */
  public SavedGame getSavedGame()
  {
    return savedGame;
  }

  public boolean hasSavedGame()
  {
    boolean has = savedGame != null;
    return has;
  }
  /* Code from template association_GetMany */
  public Game getGame(int index)
  {
    Game aGame = games.get(index);
    return aGame;
  }

  public List<Game> getGames()
  {
    List<Game> newGames = Collections.unmodifiableList(games);
    return newGames;
  }

  public int numberOfGames()
  {
    int number = games.size();
    return number;
  }

  public boolean hasGames()
  {
    boolean has = games.size() > 0;
    return has;
  }

  public int indexOfGame(Game aGame)
  {
    int index = games.indexOf(aGame);
    return index;
  }
  /* Code from template association_GetMany */
  public HighScore getHighScore(int index)
  {
    HighScore aHighScore = highScores.get(index);
    return aHighScore;
  }

  public List<HighScore> getHighScores()
  {
    List<HighScore> newHighScores = Collections.unmodifiableList(highScores);
    return newHighScores;
  }

  public int numberOfHighScores()
  {
    int number = highScores.size();
    return number;
  }

  public boolean hasHighScores()
  {
    boolean has = highScores.size() > 0;
    return has;
  }

  public int indexOfHighScore(HighScore aHighScore)
  {
    int index = highScores.indexOf(aHighScore);
    return index;
  }
  /* Code from template association_GetOne */
  public PlayPhase getPlayPhase()
  {
    return playPhase;
  }

  public boolean hasPlayPhase()
  {
    boolean has = playPhase != null;
    return has;
  }
  /* Code from template association_SetOptionalOneToOne */
  public boolean setSavedGame(SavedGame aNewSavedGame)
  {
    boolean wasSet = false;
    if (savedGame != null && !savedGame.equals(aNewSavedGame) && equals(savedGame.getPlayer()))
    {
      //Unable to setSavedGame, as existing savedGame would become an orphan
      return wasSet;
    }

    savedGame = aNewSavedGame;
    Player anOldPlayer = aNewSavedGame != null ? aNewSavedGame.getPlayer() : null;

    if (!this.equals(anOldPlayer))
    {
      if (anOldPlayer != null)
      {
        anOldPlayer.savedGame = null;
      }
      if (savedGame != null)
      {
        savedGame.setPlayer(this);
      }
    }
    wasSet = true;
    return wasSet;
  }
  /* Code from template association_MinimumNumberOfMethod */
  public static int minimumNumberOfGames()
  {
    return 0;
  }
  /* Code from template association_AddManyToManyMethod */
  public boolean addGame(Game aGame)
  {
    boolean wasAdded = false;
    if (games.contains(aGame)) { return false; }
    games.add(aGame);
    if (aGame.indexOfPlayer(this) != -1)
    {
      wasAdded = true;
    }
    else
    {
      wasAdded = aGame.addPlayer(this);
      if (!wasAdded)
      {
        games.remove(aGame);
      }
    }
    return wasAdded;
  }
  /* Code from template association_RemoveMany */
  public boolean removeGame(Game aGame)
  {
    boolean wasRemoved = false;
    if (!games.contains(aGame))
    {
      return wasRemoved;
    }

    int oldIndex = games.indexOf(aGame);
    games.remove(oldIndex);
    if (aGame.indexOfPlayer(this) == -1)
    {
      wasRemoved = true;
    }
    else
    {
      wasRemoved = aGame.removePlayer(this);
      if (!wasRemoved)
      {
        games.add(oldIndex,aGame);
      }
    }
    return wasRemoved;
  }
  /* Code from template association_AddIndexControlFunctions */
  public boolean addGameAt(Game aGame, int index)
  {  
    boolean wasAdded = false;
    if(addGame(aGame))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfGames()) { index = numberOfGames() - 1; }
      games.remove(aGame);
      games.add(index, aGame);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveGameAt(Game aGame, int index)
  {
    boolean wasAdded = false;
    if(games.contains(aGame))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfGames()) { index = numberOfGames() - 1; }
      games.remove(aGame);
      games.add(index, aGame);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addGameAt(aGame, index);
    }
    return wasAdded;
  }
  /* Code from template association_MinimumNumberOfMethod */
  public static int minimumNumberOfHighScores()
  {
    return 0;
  }
  /* Code from template association_AddManyToOne */
  public HighScore addHighScore(int aScore, Date aDateAcheived, HallOfFame aHallOfFame)
  {
    return new HighScore(aScore, aDateAcheived, this, aHallOfFame);
  }

  public boolean addHighScore(HighScore aHighScore)
  {
    boolean wasAdded = false;
    if (highScores.contains(aHighScore)) { return false; }
    Player existingPlayer = aHighScore.getPlayer();
    boolean isNewPlayer = existingPlayer != null && !this.equals(existingPlayer);
    if (isNewPlayer)
    {
      aHighScore.setPlayer(this);
    }
    else
    {
      highScores.add(aHighScore);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeHighScore(HighScore aHighScore)
  {
    boolean wasRemoved = false;
    //Unable to remove aHighScore, as it must always have a player
    if (!this.equals(aHighScore.getPlayer()))
    {
      highScores.remove(aHighScore);
      wasRemoved = true;
    }
    return wasRemoved;
  }
  /* Code from template association_AddIndexControlFunctions */
  public boolean addHighScoreAt(HighScore aHighScore, int index)
  {  
    boolean wasAdded = false;
    if(addHighScore(aHighScore))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfHighScores()) { index = numberOfHighScores() - 1; }
      highScores.remove(aHighScore);
      highScores.add(index, aHighScore);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveHighScoreAt(HighScore aHighScore, int index)
  {
    boolean wasAdded = false;
    if(highScores.contains(aHighScore))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfHighScores()) { index = numberOfHighScores() - 1; }
      highScores.remove(aHighScore);
      highScores.add(index, aHighScore);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addHighScoreAt(aHighScore, index);
    }
    return wasAdded;
  }
  /* Code from template association_SetOptionalOneToOne */
  public boolean setPlayPhase(PlayPhase aNewPlayPhase)
  {
    boolean wasSet = false;
    if (playPhase != null && !playPhase.equals(aNewPlayPhase) && equals(playPhase.getPlayer()))
    {
      //Unable to setPlayPhase, as existing playPhase would become an orphan
      return wasSet;
    }

    playPhase = aNewPlayPhase;
    Player anOldPlayer = aNewPlayPhase != null ? aNewPlayPhase.getPlayer() : null;

    if (!this.equals(anOldPlayer))
    {
      if (anOldPlayer != null)
      {
        anOldPlayer.playPhase = null;
      }
      if (playPhase != null)
      {
        playPhase.setPlayer(this);
      }
    }
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    SavedGame existingSavedGame = savedGame;
    savedGame = null;
    if (existingSavedGame != null)
    {
      existingSavedGame.delete();
    }
    ArrayList<Game> copyOfGames = new ArrayList<Game>(games);
    games.clear();
    for(Game aGame : copyOfGames)
    {
      aGame.removePlayer(this);
    }
    for(int i=highScores.size(); i > 0; i--)
    {
      HighScore aHighScore = highScores.get(i - 1);
      aHighScore.delete();
    }
    PlayPhase existingPlayPhase = playPhase;
    playPhase = null;
    if (existingPlayPhase != null)
    {
      existingPlayPhase.delete();
    }
    super.delete();
  }

}