/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.0.4181.a593105a9 modeling language!*/

package ca.mcgill.ecse223.block.model;

// line 87 "../../../../../Model.ump"
public class Wall extends PhysicalGameEntity
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Wall Associations
  private PlayArea playArea;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Wall(int aX, int aY, PlayArea aPlayArea)
  {
    super(aX, aY);
    boolean didAddPlayArea = setPlayArea(aPlayArea);
    if (!didAddPlayArea)
    {
      throw new RuntimeException("Unable to create wall due to playArea");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------
  /* Code from template association_GetOne */
  public PlayArea getPlayArea()
  {
    return playArea;
  }
  /* Code from template association_SetOneToAtMostN */
  public boolean setPlayArea(PlayArea aPlayArea)
  {
    boolean wasSet = false;
    //Must provide playArea to wall
    if (aPlayArea == null)
    {
      return wasSet;
    }

    //playArea already at maximum (4)
    if (aPlayArea.numberOfWalls() >= PlayArea.maximumNumberOfWalls())
    {
      return wasSet;
    }
    
    PlayArea existingPlayArea = playArea;
    playArea = aPlayArea;
    if (existingPlayArea != null && !existingPlayArea.equals(aPlayArea))
    {
      boolean didRemove = existingPlayArea.removeWall(this);
      if (!didRemove)
      {
        playArea = existingPlayArea;
        return wasSet;
      }
    }
    playArea.addWall(this);
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    PlayArea placeholderPlayArea = playArea;
    this.playArea = null;
    if(placeholderPlayArea != null)
    {
      placeholderPlayArea.removeWall(this);
    }
    super.delete();
  }

}