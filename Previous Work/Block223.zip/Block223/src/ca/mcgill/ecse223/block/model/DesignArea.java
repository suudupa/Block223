/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.0.4181.a593105a9 modeling language!*/

package ca.mcgill.ecse223.block.model;

// line 105 "../../../../../Model.ump"
public class DesignArea extends DisplayArea
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //DesignArea Associations
  private DesignPhase designPhase;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public DesignArea(int aWidth, int aHeight, DesignPhase aDesignPhase)
  {
    super(aWidth, aHeight);
    if (aDesignPhase == null || aDesignPhase.getDesignArea() != null)
    {
      throw new RuntimeException("Unable to create DesignArea due to aDesignPhase");
    }
    designPhase = aDesignPhase;
  }

  public DesignArea(int aWidth, int aHeight, Game aGameForDesignPhase, Admin aUserForDesignPhase)
  {
    super(aWidth, aHeight);
    designPhase = new DesignPhase(aGameForDesignPhase, aUserForDesignPhase, this);
  }

  //------------------------
  // INTERFACE
  //------------------------
  /* Code from template association_GetOne */
  public DesignPhase getDesignPhase()
  {
    return designPhase;
  }

  public void delete()
  {
    DesignPhase existingDesignPhase = designPhase;
    designPhase = null;
    if (existingDesignPhase != null)
    {
      existingDesignPhase.delete();
    }
    super.delete();
  }

}